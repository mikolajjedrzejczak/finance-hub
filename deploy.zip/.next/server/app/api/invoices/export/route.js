var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invoices/export/route.js")
R.c("server/chunks/[root-of-the-server]__0ntih-w._.js")
R.c("server/chunks/_00ndw3z._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_invoices_export_route_actions_1pur38m.js")
R.m(60455)
module.exports=R.m(60455).exports
