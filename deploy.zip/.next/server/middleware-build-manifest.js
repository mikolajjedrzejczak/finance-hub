globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/A_ab9AO2QJc9nCvtNQurh/_buildManifest.js",
    "static/A_ab9AO2QJc9nCvtNQurh/_ssgManifest.js",
    "static/A_ab9AO2QJc9nCvtNQurh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/20tuuqvsddgn2.js",
    "static/chunks/1mhtz6yjwdbtq.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/0iec5q4ack_04.js",
    "static/chunks/3mnmnlwulwja7.js",
    "static/chunks/turbopack-2pfvtvwf8iqzm.js"
  ]
};
