module.exports=[52334,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_public_invoice_%5Bid%5D_page_actions_1961xsj.js.map